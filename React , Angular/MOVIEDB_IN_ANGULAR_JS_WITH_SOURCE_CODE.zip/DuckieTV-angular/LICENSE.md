DuckieTV is Free (as in free beer) and Open Source, and comes with as little legal nonsense as possible.

You have:

- The freedom to run the program as you wish, for any purpose (freedom 0).
- The freedom to study how the program works, and change it so it does your computing as you wish (freedom 1).
- The freedom to redistribute copies so you can help your neighbor (freedom 2).
- The freedom to distribute copies of your modified versions to others (freedom 3).

You do not have:

- The permission to ask money for DuckieTV, in any shape, way or form, for instance by wrapping it in an adware-installer, requiring payment to download (evolutions of) DuckieTV, or by injecting ads to the program ever. (This applies to the original authors of DuckieTV too) 
