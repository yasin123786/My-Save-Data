console.info = function() {};

var DuckieTV = angular.module('DuckieTV', [
    'formly',
    'formlyBootstrap',
    'xmlrpc',
    'ct.ui.router.extras.core',
    'ct.ui.router.extras.sticky',
    'ngLocale',
    'ngAnimate',
    'ngMessages',
    'tmh.dynamicLocale',
    'ui.bootstrap',
    'dialogs.main',
    'DuckieTorrent.torrent',
    'toaster',
    'angular-dialgauge'
]);