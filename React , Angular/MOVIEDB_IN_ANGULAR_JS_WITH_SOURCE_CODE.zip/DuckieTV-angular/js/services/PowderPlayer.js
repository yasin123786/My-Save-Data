DuckieTV.factory('PowderPlayer', function() {




});