Fetch locales from the github repo here:

https://github.com/angular/code.angularjs.org/tree/master/1.3.0-beta.6/i18n

Direct raw link:
https://raw.githubusercontent.com/angular/code.angularjs.org/master/1.3.0-beta.6/i18n/angular-locale_nl-nl.js

Make sure to rename the last dash to an underscore so that tmhDynamicLocale can find them:

./angular-locale_nl_nl.js

Information on Chrome extension locales here:

https://developer.chrome.com/webstore/i18n?csw=1#localeTable