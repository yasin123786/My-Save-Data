import React from 'react';
import { render } from 'react-dom';
import { Reacteroids } from './Reacteroids';
import style from './style.css';

render(<Reacteroids />, document.getElementById('root'));
