# Realtime Chat Application

![Video Chat](https://i.ibb.co/7WZRLD1/122.jpg)

## Introduction
This is a code repository for the corresponding video tutorial. 

In this tutorial, we're going to build and deploy a React Video Chat Application using WebRTC.

Setup:
- run ```npm i && npm start``` for both client and server side to start the development server
