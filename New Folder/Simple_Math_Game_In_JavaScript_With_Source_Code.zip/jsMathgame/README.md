# jsMathgame
this is a math inspired project that is built with the following language: JAVASCRIPT, HTML and CSS. 
The project is a game that test your multiplication knowledge by generate a question of two random numbers with a product operator between them and generating one correct answer and three wrong answers in the answer box. 
If the player get the question score increase by one. go ahead and have fun to see how much of a score you can get. try it out
