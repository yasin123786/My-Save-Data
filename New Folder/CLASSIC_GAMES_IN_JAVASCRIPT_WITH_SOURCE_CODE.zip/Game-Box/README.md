# Game-Box
Collection of best classic games simply coded in javascript with some tricks for game development in JS.   

## Games

1. **Snake Game** : Classic snake and food game.

2. **BreakOut Game** : Have to break all the tiles using the moving ball and bar.

3. **Steal the Cupcake** : You have catch the cupcake falling from above. You can jump move left and right. This game is beautifully Design with Animations.

4. **Pig Game** : A Two Player Dice Game for Fun.

## Built With

- HTML5
- CSS
- JavaScript
- Bootstrap

## Features

- Easy to understand Code
- Basic JavaScript and other languages are used to make it simple
- Good Functionality

### You Can Play these games [Here](http://game-box01-com.stackstaging.com/).

