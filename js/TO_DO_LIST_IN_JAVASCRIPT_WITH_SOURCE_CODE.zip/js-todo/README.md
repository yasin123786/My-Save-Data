# ToDo Today
## A To Do app built with Bootstrap and JavaScript.

Add items by completing the input field and clicking the "Add Item" button or hitting the ENTER key.

Check out my app in your browsere [here](https://smissaertj.github.io/js-bts-todo/).