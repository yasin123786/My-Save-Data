GBPS Car Racing Game

Copyright and general direction for use:

- You can use this code for eduational purpose only..
- You will not try to pass our hard work as your own..
- We donot espect attribution but it will certainly make us happy..
- If you benefit from this project, do share your experience with us, we would be
- re than happy to hear from you..
- This is a work on progress so, you can send us any improvements if you will..
- The models and textures herein might be copyrighted, so you are better off using your own models in your project.


compiling.

This is based on Freeglut not original Glut and will not work with glut.
also link to Soil library.

this was originally compiled on mingw32/Gcc but will work on any compiler..
you might prefer codeblocks with mingw32 if you are unsure..


This is our first semester project on CS and is completely based on C i.e. no C++ code whasoever.


Hope you benefit..
Happy coding, Enjoy!


# Screenshots :
![Screenshot 1](https://raw.githubusercontent.com/virtualanup/3D-Car-Race/master/screenshots/scrn1.png)

![Screenshot 2](https://raw.githubusercontent.com/virtualanup/3D-Car-Race/master/screenshots/scrn2.gif)

![Screenshot 3](https://raw.githubusercontent.com/virtualanup/3D-Car-Race/master/screenshots/scrn2.jpg)

![Screenshot 4](https://raw.githubusercontent.com/virtualanup/3D-Car-Race/master/screenshots/scrn4.gif)

The GBPS team,

- Aavaas Gajurel(avs_sensation@yahoo.com)

- Anup Pokhrel(virtualanup@gmail.com)

- Manish Sharma

- Bidhan Bhattari
